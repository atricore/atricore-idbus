package com.atricore.idbus.spring.boot.demo.idau;

public class SSOIdPApplication extends org.atricore.idbus.capabilities.sso.ui.internal.SSOIdPApplication {

    //  Simple java class that extends a parent
}
